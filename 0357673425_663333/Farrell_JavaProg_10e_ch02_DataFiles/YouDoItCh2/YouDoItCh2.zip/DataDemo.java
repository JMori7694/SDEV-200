public class DataDemo {
    public static void main(String[] args) {
        int aWholeNumber = 315;
        final int STATES_IN_US = 50;
        System.out.print("The number is ");
        System.out.println(aWholeNumber);
        System.out.println("The number of states is " + STATES_IN_US);
    }
}
