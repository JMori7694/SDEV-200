public class IntegerDemo {
    public static void main(String[] args) {
        int anInt = 12;
        byte aByte = 12;
        short aShort = 12;
        long aLong = 12;

        System.out.println("The int is   " + anInt);
        System.out.println("The byte is  " + aByte);
        System.out.println("The short is " + aShort);
        System.out.println("The long is  " + aLong); 
    }
}
