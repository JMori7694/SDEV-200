// Filename Hello2.java
// Written by Sarah Lesher
// Written on 8/23/23

public class Hello2 {
    /* This class demonstrates the use of the println() 
     * method to print the message Hello, World!
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
