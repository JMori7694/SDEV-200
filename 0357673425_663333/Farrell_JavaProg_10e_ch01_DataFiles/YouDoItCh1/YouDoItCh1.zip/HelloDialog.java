// Filename HelloDialog.java
// Written by Sarah Lesher
// Written on 8/23/23

import javax.swing.JOptionPane;

public class HelloDialog {
    public static void main (String[] args) {
        JOptionPane.showMessageDialog(null, "Hello, world!");
    }
}