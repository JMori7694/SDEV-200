public class MovieQuoteInfo {
    public static void main(String[] args) {
        System.out.println("\"Imagine dying frightened and in pain and having that as the only part of you which survives.\"");
        System.out.println("Annihilation (2018)");
        System.out.println("Josie Radek");
    }
}
