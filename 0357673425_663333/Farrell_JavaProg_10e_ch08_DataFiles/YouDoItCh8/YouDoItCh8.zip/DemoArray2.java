public class DemoArray2 {
    public static void main(String[] args) {
        double[] salaries = {16.25, 17.55, 18.25, 19.85};

        System.out.println("Salaries one by one are:");
        System.out.println(salaries[0]);
        System.out.println(salaries[1]);
        System.out.println(salaries[2]);
        System.out.println(salaries[3]);
    }
}
