public class Sandwich {
    private String mainIngredient;
    private String bread;
    private double price;

    public void setMainIngredient(String sandwichIngredient) {
        mainIngredient = sandwichIngredient;
    }
    public void setBread(String sandwichBread) {
        bread = sandwichBread;
    }
    public void setPrice(double sandwichPrice) {
        price = sandwichPrice;
    }

    public String getMainIngredient {
        return mainIngredient;
    }
    public String getBread {
        return bread;
    }
    public double getPrice {
        return price;
    }
}
